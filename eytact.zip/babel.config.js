module.exports = { presets: ['@magento/peregrine'] };
